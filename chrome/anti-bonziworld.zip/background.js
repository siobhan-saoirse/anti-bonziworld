// blocking ip grabbers to prevent any malicious attacks from the skids of warsaw/pwnsec
// also blocks bonziworld, slurs, my surname and other bs from these horrible people

chrome.action.setTitle({
    title: 'Anti-BonziWORLD is active.'
});